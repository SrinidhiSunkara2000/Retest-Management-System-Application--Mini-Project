package com.example.miniproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class signup extends AppCompatActivity {
    EditText name,email,regno,phno,password;
    TextView result;
    Button signup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        result=(TextView)findViewById(R.id.result);
        name=(EditText)findViewById(R.id.name);
        email=(EditText)findViewById(R.id.email);
        regno=(EditText)findViewById(R.id.regno);
        phno=(EditText)findViewById(R.id.MobileNo);
        password=(EditText)findViewById(R.id.password);
        signup=(Button)findViewById(R.id.signupbtn);
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String checkpass=passwordValidation(name.getText().toString(), password.getText().toString());
                String numbers = "(.*[0-9].*)";

                if((name.getText().toString().length()==0)||(email.getText().toString().length()==0)||(regno.getText().toString().length()==0)||(phno.getText().toString().length()==0)||(password.getText().toString().length()==0)) {
                        result.setText("Please enter all fields");
                }
                else if((phno.getText().toString().length()!=10)){
                    result.setText("Please enter 10 digit Phone number");
                }

                else if (!regno.getText().toString().matches(numbers)){
                    result.setText("Please enter only digits in roll number");
                }

                else if(checkpass.equals("true")){
                    result.setText("Successfull");
                    signupUser(view);


                }
                else {

                    result.setText("Password "+checkpass);
                }

            }
        });

    }
    public void signupUser(View view){
        FirebaseDatabase database=FirebaseDatabase.getInstance();
        DatabaseReference rno,nameref,emailref,pref,phnoref,subref;
        rno=database.getReference().child("student").child(regno.getText().toString()).child("regno");
        rno.setValue(regno.getText().toString());
        nameref=database.getReference().child("student").child(regno.getText().toString()).child("name");
        nameref.setValue(name.getText().toString());
        emailref=database.getReference().child("student").child(regno.getText().toString()).child("email");
        emailref.setValue(email.getText().toString());
        pref=database.getReference().child("student").child(regno.getText().toString()).child("p");
        pref.setValue(password.getText().toString());
        phnoref=database.getReference().child("student").child(regno.getText().toString()).child("phno");
        phnoref.setValue(phno.getText().toString());
        subref=database.getReference().child("student").child(regno.getText().toString()).child("MobileCommunication").child("no");
        subref.setValue("true");
        subref=database.getReference().child("student").child(regno.getText().toString()).child("MobileCommunicationStatus");
        subref.setValue("Did_not_apply");
        subref=database.getReference().child("student").child(regno.getText().toString()).child("profilePic");
        subref.setValue("");
        subref=database.getReference().child("student").child(regno.getText().toString()).child("GraphTheory").child("no");
        subref.setValue("true");
        subref=database.getReference().child("student").child(regno.getText().toString()).child("GraphTheoryStatus");
        subref.setValue("Did_not_apply");




    }
    public String passwordValidation(String userName, String password)
    {
        String statement = null;
        boolean valid = true;
        if (password.length() > 15 || password.length() < 8)
        {
            return("should be less than 15 and more than 8 characters in length.");
        }
        if (password.indexOf(userName) > -1)
        {
            return("Should not be same as user name");

        }
        String upperCaseChars = "(.*[A-Z].*)";
        if (!password.matches(upperCaseChars ))
        {

            return("Password should contain atleast one upper case alphabet");

        }
        String lowerCaseChars = "(.*[a-z].*)";
        if (!password.matches(lowerCaseChars ))
        {
            return("Password should contain atleast one lower case alphabet");

        }
        String numbers = "(.*[0-9].*)";
        if (!password.matches(numbers ))
        {
            return("Password should contain atleast one number.");

        }
        String specialChars = "(.*[,~,!,@,#,$,%,^,&,*,(,),-,_,=,+,[,{,],},|,;,:,<,>,/,?].*$)";
        if (!password.matches(specialChars ))
        {
            return ("Password should contain atleast one special character");

        }
        return("true");

    }
}



package com.example.miniproject;

public class graphprofile {
    private String name,reason,unittest;
    private String email;
    private String profilePic;
    private String p,regno;
    private Boolean permission;
    private String GraphTheoryStatus;

    public graphprofile(String name, String reason, String unittest, String email, String profilePic, String p, String regno, Boolean permission, String graphTheoryStatus) {
        this.name = name;
        this.reason = reason;
        this.unittest = unittest;
        this.email = email;
        this.profilePic = profilePic;
        this.p = p;
        this.regno = regno;
        this.permission = permission;
        GraphTheoryStatus = graphTheoryStatus;
    }

    public graphprofile() {
    }

    public graphprofile(String name, String email, String profilePic, String p, String regno, Boolean permission, String graphTheoryStatus) {
        this.name = name;
        this.email = email;
        this.profilePic = profilePic;
        this.p = p;
        this.regno = regno;
        this.permission = permission;
        GraphTheoryStatus = graphTheoryStatus;
    }
    public String getReason() {
        return reason;
    }

    public void setUnittest(String unittest) {
        this.unittest = unittest;
    }
    public String getUnittest() {
        return unittest;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getP() {
        return p;
    }

    public void setP(String p) {
        this.p = p;
    }

    public String getRegno() {
        return regno;
    }

    public void setRegno(String regno) {
        this.regno = regno;
    }

    public Boolean getPermission() {
        return permission;
    }

    public void setPermission(Boolean permission) {
        this.permission = permission;
    }

    public String getGraphTheoryStatus() {
        return GraphTheoryStatus;
    }

    public void setGraphTheoryStatus(String graphTheoryStatus) {
        GraphTheoryStatus = graphTheoryStatus;
    }
}

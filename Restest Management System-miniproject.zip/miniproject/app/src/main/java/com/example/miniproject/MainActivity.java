package com.example.miniproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity{
    Button login;
    EditText regno,password;
    TextView noaccount;
    RadioGroup radioGroup;
    RadioButton radioButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        regno=(EditText)findViewById(R.id.email);
        password=(EditText)findViewById(R.id.loginpassword);
        radioGroup=(RadioGroup)findViewById(R.id.radiogroup);
        login=(Button)findViewById(R.id.login);
       // test=(Button)findViewById(R.id.test);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Toast.makeText(MainActivity.this,regno.getText().toString(),Toast.LENGTH_SHORT).show();
//                Toast.makeText(MainActivity.this,password.getText().toString(),Toast.LENGTH_SHORT).show();
                int radioId=radioGroup.getCheckedRadioButtonId();
                radioButton=findViewById(radioId);
                if(radioButton.getText().toString().equals("student")){
                    loginUser(view);
                }
                else{
                    loginTeacher(view);
                }


            }
        });
//        test.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(MainActivity.this,viewapplications.class);
//                startActivity(intent);
//            }
//        });
        noaccount=(TextView)findViewById(R.id.noaccount);
        noaccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,signup.class);
                startActivity(intent);
            }
        });

    }
    public void loginUser(View view){
        FirebaseDatabase database=FirebaseDatabase.getInstance();
        //String rno=regno.getText().toString();
        DatabaseReference myRef =database.getReference().child("student").child(regno.getText().toString());
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String value=dataSnapshot.child("p").getValue(String.class);
                Toast.makeText(MainActivity.this,value,Toast.LENGTH_SHORT).show();
                //Toast.makeText(MainActivity.this,regno.getText().toString(),Toast.LENGTH_SHORT).show();

                String pass=password.getText().toString();

                if(value.equals(pass)){
                    //Toast.makeText(MainActivity.this,"correct password",Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(MainActivity.this,form.class);
                    intent.putExtra("regno",regno.getText().toString());
                    startActivity(intent);
                }
                else{
                    Toast.makeText(MainActivity.this,"wrong password",Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(MainActivity.this,"Failed",Toast.LENGTH_SHORT).show();
            }
        });

    }
    public void loginTeacher(final View view){
        FirebaseDatabase database=FirebaseDatabase.getInstance();
        //String rno=regno.getText().toString();
        DatabaseReference myRef =database.getReference().child("Teacher").child(regno.getText().toString());
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String value=dataSnapshot.child("password").getValue(String.class);
                String subject=dataSnapshot.child("subject").getValue(String.class);
                Toast.makeText(MainActivity.this,value,Toast.LENGTH_SHORT).show();
                //Toast.makeText(MainActivity.this,regno.getText().toString(),Toast.LENGTH_SHORT).show();

                String pass=password.getText().toString();


                if(value.equals(pass)){
                    //Toast.makeText(MainActivity.this,subject,Toast.LENGTH_SHORT).show();
                    if(subject.equals("MobileCommunication")){
                    Intent intent = new Intent(MainActivity.this,viewapplications.class);
                    startActivity(intent);}
                    if(subject.equals("GraphTheory")){
                        Intent intent = new Intent(MainActivity.this,graphapplications.class);
                        startActivity(intent);}

                }
                else{
                    Toast.makeText(MainActivity.this,"wrong password",Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(MainActivity.this,"Failed",Toast.LENGTH_SHORT).show();
            }
        });

    }



}

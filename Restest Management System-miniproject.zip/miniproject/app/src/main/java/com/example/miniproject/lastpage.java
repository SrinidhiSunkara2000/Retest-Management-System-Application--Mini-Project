package com.example.miniproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class lastpage extends AppCompatActivity {
    String regno,subject,status,no;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lastpage);
        Intent intent = getIntent();
        regno = intent.getStringExtra("regno");
        subject=intent.getStringExtra("subject");
        status=intent.getStringExtra("status");
        no=intent.getStringExtra("number");

        Toast.makeText(lastpage.this,no,Toast.LENGTH_SHORT).show();

        DatabaseReference myRef1= FirebaseDatabase.getInstance().getReference().child("student").child(regno).child(subject);
        myRef1.child("status").setValue(status);
    }
}

package com.example.miniproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class form extends AppCompatActivity {
    String subject,attendance,utno,reason;
    String regno,status;
    TextView result,logout;
    Button apply,checkstatus;
    EditText reasonurl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);

        Intent intent = getIntent();
        regno = intent.getStringExtra("regno");
        result=(TextView)findViewById(R.id.result);
        logout=(TextView)findViewById(R.id.logouttext3);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(form.this,MainActivity.class);
                startActivity(intent);
            }
        });
        reasonurl=(EditText)findViewById(R.id.reasonurl);
        Spinner spinner = findViewById(R.id.spinner1);

        ArrayAdapter<CharSequence> adapter= ArrayAdapter.createFromResource(this,R.array.subjects,R.layout.color_spinner_layout);
        adapter.setDropDownViewResource(R.layout.spinner_dropdown_layout);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                subject=adapterView.getItemAtPosition(i).toString();
                Toast.makeText(form.this,subject,Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        Spinner spinner2 = findViewById(R.id.spinner2);
        ArrayAdapter<CharSequence> adapter2= ArrayAdapter.createFromResource(this,R.array.utno,R.layout.color_spinner_layout);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter2);
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                utno=adapterView.getItemAtPosition(i).toString();
                //Toast.makeText(adapterView.getContext(),utno,Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
//        Spinner spinner4 = findViewById(R.id.spinner4);
//        ArrayAdapter<CharSequence> adapter4= ArrayAdapter.createFromResource(this,R.array.section,android.R.layout.simple_spinner_item);
//        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        spinner4.setAdapter(adapter4);
//        spinner4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
//                section=adapterView.getItemAtPosition(i).toString();
//                Toast.makeText(adapterView.getContext(),section,Toast.LENGTH_SHORT).show();
//
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> adapterView) {
//
//            }
//        });
        Spinner spinner5 = findViewById(R.id.spinner5);
        ArrayAdapter<CharSequence> adapter5= ArrayAdapter.createFromResource(this,R.array.reasonforretest,R.layout.color_spinner_layout);
        adapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner5.setAdapter(adapter5);
        spinner5.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                reason=adapterView.getItemAtPosition(i).toString();
                //Toast.makeText(adapterView.getContext(),reason,Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        Spinner spinner6 = findViewById(R.id.spinner6);
        ArrayAdapter<CharSequence> adapter6= ArrayAdapter.createFromResource(this,R.array.attendance,R.layout.color_spinner_layout);
        adapter6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner6.setAdapter(adapter6);
        spinner6.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                attendance=adapterView.getItemAtPosition(i).toString();
                //Toast.makeText(adapterView.getContext(),attendance,Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        apply=(Button)findViewById(R.id.apply);
        apply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Integer number;
                if(attendance.equals("less than 75")){
                    Toast.makeText(form.this,"cannot apply",Toast.LENGTH_SHORT).show();
                }
                else{
                    FirebaseDatabase database=FirebaseDatabase.getInstance();
                    final DatabaseReference myRef =database.getReference().child("student").child(regno);
                    myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                             String value = dataSnapshot.child(subject).child("no").getValue(String.class);
                             if(value.equals("true")){
                                status="Pending";
                                 DatabaseReference myRef1=FirebaseDatabase.getInstance().getReference().child("student").child(regno);
                                 myRef1.child("reason").setValue(reason);
                                 myRef1.child("unittest").setValue(utno);
                                 myRef1.child("profilePic").setValue(reasonurl.getText().toString());
                                 myRef1.child(subject+"Status").setValue(status);
                                 myRef1.child(subject).child("no").setValue("false");
//                                 result.setText(status);
//                                Toast.makeText(form.this,"Pending",Toast.LENGTH_SHORT).show();

                             }
                             else if(value.equals("false")){
                                status="Cannot";
                                 DatabaseReference myRef1=FirebaseDatabase.getInstance().getReference().child("student").child(regno);
                                 myRef1.child(subject+"Status").setValue(status);
                                 myRef1.child("reason").setValue(reason);
                                 myRef1.child("profilePic").setValue(reasonurl.getText().toString());
                                 myRef1.child("unittest").setValue(utno);
                                 //myRef1.child("no").setValue(no);
//                                result.setText("Cannot apply");
//                                Toast.makeText(form.this,status,Toast.LENGTH_SHORT).show();
                             }




//                             if(no==0){
//                                 myRef.child(subject).child("status").setValue("pending");
//                             }
//                            if(no>0){
//                                myRef.child(subject).child("status").setValue("cannot apply for this subject");
//                            }
//                             Intent intent = new Intent(form.this,status.class);
//                             intent.putExtra("number",no.toString());
//                             intent.putExtra("regno",regno);
//                             intent.putExtra("subject",subject);
//                             startActivity(intent);

                        }


                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            Toast.makeText(form.this,"Failed",Toast.LENGTH_SHORT).show();
                        }
                    });
               }




            }
        });
        checkstatus=(Button)findViewById(R.id.checkstatus);
        checkstatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                            Intent intent = new Intent(form.this,status.class);
                            intent.putExtra("regno",regno);
                            startActivity(intent);

            }
        });

    }


}
// no+=1;
//         FirebaseDatabase database1=FirebaseDatabase.getInstance();
//         DatabaseReference myRef1 =database1.getReference().child("student").child(regno).child(subject);
//         myRef1.setValue(no.toString());

package com.example.miniproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class status extends AppCompatActivity {
    TextView mcstatus,graphstatus;
    String subject;
    String regno,status;
    String no;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status);
        Intent intent = getIntent();
        regno = intent.getStringExtra("regno");

        mcstatus=(TextView)findViewById(R.id.mobilestatus);
        graphstatus=(TextView)findViewById(R.id.graphstatus);

        DatabaseReference myRef1=FirebaseDatabase.getInstance().getReference().child("student").child(regno);
        myRef1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String value1 = dataSnapshot.child("MobileCommunicationStatus").getValue(String.class);
                String value2 = dataSnapshot.child("GraphTheoryStatus").getValue(String.class);
                mcstatus.setText("MC: "+value1);
                graphstatus.setText("GT: "+value2);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
//        myRef1.child("no").setValue(no);
       // statusView.setText(status);
//            Intent intent1 = new Intent(status.this, lastpage.class);
//            intent1.putExtra("number", no.toString());
//            intent1.putExtra("regno", regno);
//            intent1.putExtra("subject", subject);
//            intent1.putExtra("status",status);
//            startActivity(intent1);
        }
}

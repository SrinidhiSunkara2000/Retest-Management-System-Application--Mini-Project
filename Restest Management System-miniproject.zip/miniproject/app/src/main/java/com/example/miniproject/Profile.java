package com.example.miniproject;

public class Profile {
    private String name,unittest;
    private String email;
    private String profilePic;
    private String reason,regno;
    private Boolean permission;
    private String MobileCommunicationStatus;

    public String getReason() {
        return reason;
    }

    public void setUnittest(String unittest) {
        this.unittest = unittest;
    }
    public String getUnittest() {
        return unittest;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Profile() {
    }

    public String getRegno() {
        return regno;
    }

    public void setRegno(String regno) {
        this.regno = regno;
    }

    public Profile(String name, String email, String profilePic, String reason, String regno, Boolean permission, String mobileCommunicationStatus) {
        this.name = name;
        this.email = email;
        this.profilePic = profilePic;
        this.reason = reason;
        this.regno = regno;
        this.permission = permission;
        MobileCommunicationStatus = mobileCommunicationStatus;
    }


    public String getMobileCommunicationStatus() {
        return MobileCommunicationStatus;
    }

    public void setMobileCommunicationStatus(String mobileCommunicationStatus) {
        MobileCommunicationStatus = mobileCommunicationStatus;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public Boolean getPermission() {
        return permission;
    }

    public void setPermission( boolean permission) {
        this.permission = permission;
    }
}
